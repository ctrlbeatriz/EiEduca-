"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Search, Brain, Users, Target, Sparkles, Clock, BookOpen, Filter } from "lucide-react"

const courses = [
  {
    id: 1,
    title: "Inteligência Artificial na Educação",
    description: "Aprenda como a IA pode personalizar o ensino e promover inclusão digital",
    category: "IA e Tecnologia",
    level: "Intermediário",
    duration: "8 semanas",
    progress: 65,
    enrolled: true,
    icon: Brain,
    color: "primary",
  },
  {
    id: 2,
    title: "Metodologias Ativas de Ensino",
    description: "Explore técnicas inovadoras para engajar estudantes e promover aprendizado ativo",
    category: "Pedagogia",
    level: "Básico",
    duration: "6 semanas",
    progress: 40,
    enrolled: true,
    icon: Users,
    color: "secondary",
  },
  {
    id: 3,
    title: "Tecnologia Assistiva",
    description: "Ferramentas e recursos para promover acessibilidade e inclusão digital",
    category: "Acessibilidade",
    level: "Intermediário",
    duration: "10 semanas",
    progress: 0,
    enrolled: false,
    icon: Target,
    color: "accent",
  },
  {
    id: 4,
    title: "Gestão Educacional Inovadora",
    description: "Práticas de qualidade e inovação para instituições de ensino",
    category: "Gestão",
    level: "Avançado",
    duration: "12 semanas",
    progress: 0,
    enrolled: false,
    icon: Sparkles,
    color: "primary",
  },
  {
    id: 5,
    title: "Educação Inclusiva na Prática",
    description: "Estratégias para criar ambientes de aprendizado verdadeiramente inclusivos",
    category: "Inclusão",
    level: "Básico",
    duration: "8 semanas",
    progress: 0,
    enrolled: false,
    icon: Users,
    color: "secondary",
  },
  {
    id: 6,
    title: "Avaliação e Monitoramento Pedagógico",
    description: "Técnicas modernas para acompanhar o desenvolvimento dos estudantes",
    category: "Avaliação",
    level: "Intermediário",
    duration: "6 semanas",
    progress: 0,
    enrolled: false,
    icon: Target,
    color: "accent",
  },
]

const categories = ["Todos", "IA e Tecnologia", "Pedagogia", "Acessibilidade", "Gestão", "Inclusão", "Avaliação"]

export default function CursosPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("Todos")

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "Todos" || course.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const enrolledCourses = filteredCourses.filter((c) => c.enrolled)
  const availableCourses = filteredCourses.filter((c) => !c.enrolled)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl font-bold text-balance sm:text-3xl">Catálogo de Cursos</h1>
          <p className="mt-2 text-sm text-muted-foreground text-pretty sm:text-base">
            Explore cursos sobre educação inclusiva, tecnologia assistiva e metodologias inovadoras
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-6 space-y-3 sm:mb-8 sm:space-y-4">
          <div className="relative">
            <Search
              className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              type="search"
              placeholder="Buscar cursos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-11 pl-10"
              aria-label="Buscar cursos"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <Filter className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="shrink-0 whitespace-nowrap bg-transparent text-xs sm:text-sm"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Enrolled Courses */}
        {enrolledCourses.length > 0 && (
          <section className="mb-8 sm:mb-12" aria-labelledby="enrolled-courses">
            <h2 id="enrolled-courses" className="mb-3 text-lg font-semibold sm:mb-4 sm:text-xl">
              Meus Cursos
            </h2>
            <div className="grid gap-4 sm:gap-6 md:grid-cols-2">
              {enrolledCourses.map((course) => {
                const Icon = course.icon
                return (
                  <Card key={course.id} className="overflow-hidden">
                    <div className="flex flex-col sm:flex-row">
                      <div className={`bg-${course.color}/10 flex items-center justify-center p-6 sm:w-40 sm:p-8`}>
                        <Icon className={`h-10 w-10 text-${course.color} sm:h-12 sm:w-12`} aria-hidden="true" />
                      </div>
                      <div className="flex flex-1 flex-col p-4 sm:p-6">
                        <div className="mb-2 flex flex-wrap items-center gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {course.category}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {course.level}
                          </Badge>
                        </div>
                        <CardTitle className="mb-2 text-base sm:text-lg">{course.title}</CardTitle>
                        <CardDescription className="mb-4 flex-1 text-sm">{course.description}</CardDescription>
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 text-xs text-muted-foreground sm:text-sm">
                            <Clock className="h-4 w-4" aria-hidden="true" />
                            <span>{course.duration}</span>
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">Progresso</span>
                              <span className="font-medium">{course.progress}%</span>
                            </div>
                            <Progress value={course.progress} className="h-2" />
                          </div>
                          <Button className="w-full text-sm">Continuar Curso</Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>
          </section>
        )}

        {/* Available Courses */}
        {availableCourses.length > 0 && (
          <section aria-labelledby="available-courses">
            <h2 id="available-courses" className="mb-3 text-lg font-semibold sm:mb-4 sm:text-xl">
              Cursos Disponíveis
            </h2>
            <div className="grid gap-4 sm:grid-cols-2 sm:gap-6 lg:grid-cols-3">
              {availableCourses.map((course) => {
                const Icon = course.icon
                return (
                  <Card key={course.id} className="flex flex-col">
                    <CardHeader className="p-4 sm:p-6">
                      <div
                        className={`mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-${course.color}/10 sm:h-14 sm:w-14`}
                      >
                        <Icon className={`h-6 w-6 text-${course.color} sm:h-7 sm:w-7`} aria-hidden="true" />
                      </div>
                      <div className="mb-2 flex flex-wrap items-center gap-2">
                        <Badge variant="secondary" className="text-xs">
                          {course.category}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {course.level}
                        </Badge>
                      </div>
                      <CardTitle className="text-base sm:text-lg">{course.title}</CardTitle>
                      <CardDescription className="flex-1 text-sm">{course.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="mt-auto p-4 pt-0 sm:p-6 sm:pt-0">
                      <div className="mb-4 flex items-center gap-2 text-xs text-muted-foreground sm:text-sm">
                        <Clock className="h-4 w-4" aria-hidden="true" />
                        <span>{course.duration}</span>
                      </div>
                      <Button variant="outline" className="w-full bg-transparent text-sm">
                        Inscrever-se
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </section>
        )}

        {filteredCourses.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <BookOpen className="mb-4 h-12 w-12 text-muted-foreground" aria-hidden="true" />
            <h3 className="mb-2 text-base font-semibold sm:text-lg">Nenhum curso encontrado</h3>
            <p className="text-sm text-muted-foreground">Tente ajustar sua busca ou filtros para encontrar cursos</p>
          </div>
        )}
      </main>
    </div>
  )
}
